package com.nayeem.weather;

import android.app.Activity;
import android.content.SharedPreferences;

/**
 * Created by Nayeem on 5/8/2016.
 */
public class CityPreference {

    SharedPreferences prefs;

    public CityPreference(Activity activity){
        prefs = activity.getPreferences(Activity.MODE_PRIVATE);
}

    String getCity(){
        return prefs.getString("city", "London,GB");
    }

    void setCity(String city){
        prefs.edit().putString("city", city).commit();
    }

}